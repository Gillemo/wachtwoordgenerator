package jonathan.wachtwoordgenerator;

/**
 *
 * @author Jonathan van Es
 */
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class GeneratorLayout extends JPanel {

    //Attributen
    private int aantal;
    private int lengte;
    
    // getters en de settters
    public int getAantal() {
        return aantal;
    }
    
    public void setAantal(String aantal) {
        this.aantal = Integer.parseInt(aantal);
    }

        public int getLengte() {
        return lengte;
    }
        
    public void setLengte(String lengte) {
        this.lengte =  Integer.parseInt(lengte);
    }

    //de GUI word gemaakt en op het scherm vertoond
    public final JLabel     aantalWachtwoorden     = new JLabel     ("Hoeveel wachtwoorden moeten er gegenereerd worden: ");
    public final JTextField wachtwoordTextField    = new JTextField (10);
    public final JLabel     lengteWachtwooorden    = new JLabel     ("Hoelang moeten de wachtwoorden zijn: ");
    public final JTextField nameTextField          = new JTextField (10);
    public final JButton    genereerKnop           = new JButton ("Genereer");
    public final JButton    exitKnop               = new JButton ("Exit");

    public GeneratorLayout() {
        JPanel flow1Panel  = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 5));
        JPanel flow2Panel  = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JPanel gridPanel   = new JPanel(new GridLayout(2, 1));

        flow1Panel.add(aantalWachtwoorden);
        flow1Panel.add(wachtwoordTextField);
        flow1Panel.add(lengteWachtwooorden);
        flow1Panel.add(nameTextField);

        flow2Panel.add(genereerKnop);
        flow2Panel.add(exitKnop);

        gridPanel.add(flow1Panel);
        gridPanel.add(flow2Panel);

        add(gridPanel, BorderLayout.WEST);

        //indien op genereer word geklikt de genereerKnophandler klasse word aangesproken
        genereerKnop.addActionListener(new GenereerKnophandler(this));

        //indien op exit word geklikt de dispose method word aangesproken die het programma afsluit
        exitKnop.addActionListener(event -> Frame.dispose());
    }

}
