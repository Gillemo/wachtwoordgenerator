package jonathan.wachtwoordgenerator;

/**
 *
 * @author  Jonathan van Es
 */
import javax.swing.JOptionPane;
import javax.swing.JList;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GenereerKnophandler implements ActionListener {
    private final GeneratorLayout generatorLayout;

    //constructor
    public GenereerKnophandler(GeneratorLayout generatorLayout) {
        this.generatorLayout = generatorLayout;
    }

    //actie die word autgevoerd als "genereer" word geklikt
    public void actionPerformed(ActionEvent e) {
        try {
        if (e.getSource() == generatorLayout.genereerKnop) { 
            //haalt de input "aantal wachtwoorden" en zet het om in een integer
            generatorLayout.setAantal(generatorLayout.wachtwoordTextField.getText());
            int aantalWW = generatorLayout.getAantal();


            //haalt de input "lengte wachtwoord" en zet het in een integer
            generatorLayout.setLengte(generatorLayout.nameTextField.getText());
            int lengteWW = generatorLayout.getLengte();

            //de wachtwoord generator
            String[] randomPasswords = new String[aantalWW];
            for (int i = 0; i < aantalWW; i++) {
                //de array van wachtwoorden word gemaakt
                randomPasswords[i] = PasswordGenerator.getRandomPassword(lengteWW);
            }
           
            //zet de wachtwoorden in het scherm
            JOptionPane.showMessageDialog(null, new JList(randomPasswords));
            Frame.dispose();                           
        }
    }
        //de foutmelding wanneer foutive invoer word ingevoerd
        catch (Exception z){
            JOptionPane.showMessageDialog(generatorLayout, "Geen geldige invoer, alleen cijfers invoeren");
        }
                
                }
}



