package jonathan.wachtwoordgenerator;

/**
 *
 * @author Jonathan van Es
 */
public class PasswordGenerator {

    public static String getRandomPassword(int length) {
        //Genereer willekeurig een teken voor de wachtwoordlengte
        String password = "";
        for (int j = 0; j < length; j++) {
            //voeg kleine en hooofdletters aan de String
            password += PasswordGenerator.getRandomChar();
        }
        return password;
    }

    //maakt een functie die willekeurig een kleine letter, hoofdletter of cijfer genereert
    private static char getRandomChar() {
        //Het nummer wordt vermenigvuldigt met Math.random() 62 omdat er 26 kleine letters, 26 hoofdletters en 10 cijfers zijn in ASCII
        int rand = (int) (Math.random() * 62);
       
        if (rand <= 9) {
            //cijfers (48-57 in ASCII)  
            //Om van 0-9 naar 48-57 te converteren, word er 48 toegevoegd aan rand omdat 48-0 = 48
            int number = rand + 48;
            //de int word omgezet naar een char
            return (char) (number);
            
        } else if (rand <= 35) {
            //hoofdletters (65-90 in ASCII)
            //Om van 10-35 naar 65-90 te converteren, word er 55 opgetelt bij rand omdat 65-10 = 55
            int uppercase = rand + 55;
            //de int word omgezet naar een char
            return (char) (uppercase);
            
        } else {       
            //kleine letters (97-122 in ASCII)
            //Om van 36-61 naar 97-122 te converteren, word er 61 opgetelt bij rand omdat 97-36 = 61
            int lowercase = rand + 61;
            //de int word omgezet naar een char
            return (char) (lowercase);
        }
    }
}

