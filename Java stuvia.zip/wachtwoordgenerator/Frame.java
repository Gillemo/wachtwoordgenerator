package jonathan.wachtwoordgenerator;

/**
 *
 * @author Jonathan van Es
 */
import javax.swing.JFrame;
import javax.swing.WindowConstants;

public class Frame {

    public Frame() {
        //maakt het frame
        JFrame frame = new JFrame();
        frame.setSize(950, 200);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setTitle("Wachwoord generator");
        frame.setContentPane(new GeneratorLayout());
        frame.setVisible(true);
    }

    //method die het programma afsluit
    public static void dispose() {
        System.exit (0); 
    }
}
